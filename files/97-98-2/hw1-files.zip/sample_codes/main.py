import peak
import trace
import algoritthm
import json


def load_problem(file="problem.py", variable="problemMatrix"):
    namespace = dict()
    with open(file) as handle:
        exec(handle.read(), namespace)
    return peak.create_problem(namespace[variable])


"""
if you change the problem.py and an algorithm is incorrect
it prints "this algorithm works incorrectly ..." 
"""


def main():
    problem = load_problem("problem.py")

    algorithm_list = [("Algorithm 1", algoritthm.algorithm1),
                      ("Algorithm 2", algoritthm.algorithm2),
                      ("Algorithm 3", algoritthm.algorithm3),
                      ("Algorithm 4", algoritthm.algorithm4),
                      ("Algorithm 5", algoritthm.algorithm5)]

    steps = []

    for (name, function) in algorithm_list:
        tracer = trace.TraceRecord()
        peak = function(problem, trace=tracer)
        steps.append(tracer.sequence)

        status = "this algorithm works incorrectly and this location is not peak"
        if problem.is_peak(peak):
            status = "is a peak"

        print(name + " : " + str(peak) + " => " + status)

    # updating the json file
    with open("trace.jsonp", "w") as traceFile:
        traceFile.write("parse(")
        json.dump({
            "input": problem.array,
            "steps": steps
        }, traceFile)
        traceFile.write(")")


main()
