import peak
import trace

"""all algorithms return location of peak"""


def algorithm1(problem, trace=None):
    if problem.numRow <= 0 or problem.numCol <= 0:
        return None

    mid = problem.numCol // 2

    sub_start_row = 0
    sub_num_rows = problem.numRow
    sub_start_column1 = 0
    sub_num_column1 = mid
    sub_start_column2 = mid + 1
    sub_num_column2 = problem.numCol - (mid + 1)

    subproblems = []
    subproblems.append((sub_start_row, sub_start_column1, sub_num_rows, sub_num_column1))
    subproblems.append((sub_start_row, sub_start_column2, sub_num_rows, sub_num_column2))

    # get a list of all locations in the dividing column
    divider = []
    for i in range(problem.numRow):
        divider.append((i, mid))

    # find the maximum in the dividing column
    best_location = problem.get_maximum(divider, trace)

    # neighbor is the greatest neighbor of the greatest cell in mid column
    neighbor = problem.get_better_neighbor(best_location, trace)

    # this is a peak, so return it
    if neighbor == best_location:
        if trace is not None:
            trace.found_peak(best_location)
        return best_location

    # then recursively solve the problem
    sub = problem.get_subproblem_containing(subproblems, neighbor)
    if trace is not None:
        trace.set_problem_dimensions(sub)
    result = algorithm1(sub, trace)
    return problem.get_location_in_self(sub, result)


# starting from (0, 0) in each step, we go to the greatest cell
def algorithm2(problem, location=(0, 0), trace=None):
    if problem.numRow <= 0 or problem.numCol <= 0:
        return None

    next_location = problem.get_better_neighbor(location, trace)

    if next_location == location:
        if trace is not None:
            trace.found_peak(location)
        return location
    else:
        return algorithm2(problem, next_location, trace)


def algorithm3(problem, best_seen=None, trace=None):
    if problem.numRow <= 0 or problem.numCol <= 0:
        return None

    mid_row = problem.numRow // 2
    mid_col = problem.numCol // 2

    # first, get the list of all subproblems
    subproblems = []

    # our sub_problems added to subproblem list
    subproblems.append((0, 0, mid_row, mid_col))
    subproblems.append((0, mid_col + 1, mid_row, problem.numCol - (mid_col + 1)))
    subproblems.append((mid_row + 1, 0, problem.numRow - (mid_row + 1), mid_col))
    subproblems.append((mid_row + 1, mid_col + 1, problem.numRow - (mid_row + 1), problem.numCol - (mid_col + 1)))

    # list of all locations of cells in mid column and mid row
    our_plus = []
    for i in range(problem.numCol):
        our_plus.append((mid_row, i))
    for i in range(problem.numRow):
        our_plus.append((i, mid_col))

    cross_location = problem.get_maximum(our_plus, trace)
    neighbor = problem.get_better_neighbor(cross_location, trace)

    if best_seen is None or problem.get(neighbor) > problem.get(best_seen):
        best_seen = neighbor
        if trace is not None:
            trace.set_best_seen(best_seen)

    if neighbor == cross_location:
        if trace is not None:
            trace.found_peak(cross_location)
        return cross_location

    # recursively we do this algorithm
    sub = problem.get_subproblem_containing(subproblems, best_seen)
    best_new = sub.get_location_in_self(problem, best_seen)
    if trace is not None:
        trace.set_problem_dimensions(sub)
    result = algorithm3(sub, best_new, trace)
    return problem.get_location_in_self(sub, result)


def algorithm4(problem, best_seen=None, row_split=True, trace=None):
    if problem.numRow <= 0 or problem.numCol <= 0:
        return None

    subproblems = []
    divider = []

    # in this algorithm we have two ways: row_split and column_split
    if row_split:
        # same as algorithm1
        mid = problem.numRow // 2

        subproblems.append((0, 0, mid, problem.numCol))
        subproblems.append((mid + 1, 0, problem.numRow - (mid + 1), problem.numCol))

        # get a list of all locations in the dividing column
        divider = []
        for i in range(problem.numCol):
            divider.append((mid, i))
    else:
        # same as algorithm1
        mid = problem.numCol // 2

        subproblems.append((0, 0, problem.numRow, mid))
        subproblems.append((0, mid + 1, problem.numRow, problem.numCol - (mid + 1)))

        divider = []
        for i in range(problem.numRow):
            divider.append((i, mid))

    # we find maximum in our row or column
    best_location = problem.get_maximum(divider, trace)
    neighbor = problem.get_better_neighbor(best_location, trace)

    if best_seen is None or problem.get(neighbor) > problem.get(best_seen):
        best_seen = neighbor
        if trace is not None:
            trace.set_best_seen(best_seen)

    # if that's peak, return it
    if neighbor == best_location and problem.get(best_location) >= problem.get(best_seen):
        if trace is not None:
            trace.found_peak(best_location)
        return best_location

    sub = problem.get_subproblem_containing(subproblems, best_seen)
    best_new = sub.get_location_in_self(problem, best_seen)
    if trace is not None:
        trace.set_problem_dimensions(sub)
    result = algorithm4(sub, best_new, not row_split, trace)
    return problem.get_location_in_self(sub, result)


def algorithm5(problem, trace=None):
    if problem.numRow <= 0 or problem.numCol <= 0:
        return None
    divider = []
    subproblems = []

    midRow = problem.numRow // 2
    midColumn = problem.numCol // 2

    subproblems.append((1, 1, midRow - 1, midColumn - 1))
    subproblems.append((1, midColumn + 1, midRow - 1, problem.numCol - midColumn - 2))
    subproblems.append((midRow + 1, 1, problem.numRow - midRow - 2, midColumn - 1))
    subproblems.append((midRow + 1, midColumn + 1, problem.numRow - midRow - 2, problem.numCol - midColumn - 2))

    for i in range(problem.numRow):
        divider.append((i, 0))
        divider.append((i, midColumn))
        divider.append((i, problem.numCol - 1))

    for i in range(problem.numCol):
        divider.append((0, i))
        divider.append((midRow, i))
        divider.append((problem.numRow - 1, i))

    # we find maximum in our row or column
    best_location = problem.get_maximum(divider, trace)
    neighbor = problem.get_better_neighbor(best_location, trace)

    if neighbor == best_location:
        if trace is not None:
            trace.found_peak(best_location)
        return best_location

    sub = problem.get_subproblem_containing(subproblems, neighbor)
    if trace is not None:
        trace.set_problem_dimensions(sub)
    result = algorithm5(sub, trace)
    return problem.get_location_in_self(sub, result)
