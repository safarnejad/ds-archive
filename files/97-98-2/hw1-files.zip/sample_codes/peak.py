import trace


class peak(object):
    def __init__(self, array, bounds):
        (startRow, startCol, numRow, numCol) = bounds

        self.array = array
        self.bounds = bounds
        self.startRow = startRow
        self.startCol = startCol
        self.numRow = numRow
        self.numCol = numCol

    # returns number in this location
    def get(self, location):
        (x, y) = location
        if not self.is_in_matrix(x, y):
            return 0
        return self.array[self.startRow + x][self.startCol + y]

    def get_better_neighbor(self, location, trace=None):

        (x, y) = location
        best = location

        a = [-1, 0, 1, 0]
        b = [0, -1, 0, 1]

        for i in range(4):
            if self.is_in_matrix(x + a[i], y + b[i]) and \
                    self.get((x + a[i], y + b[i])) > self.get(best):
                best = (x + a[i], y + b[i])

        if trace is not None:
            trace.get_better_neighbor(location, best)

        return best

    # returns location of maximum number in a list of locations
    def get_maximum(self, locations, trace=None):
        (best_location, best_value) = (None, 0)

        for loc in locations:
            if best_location is None or self.get(loc) > best_value:
                best_location = loc
                best_value = self.get(loc)

        if trace is not None:
            trace.get_maximum(locations, best_location)

        return best_location

    # checks if a location is in matrix or not
    def is_in_matrix(self, x, y):
        if x < 0 or x >= self.numRow:
            return False
        if y < 0 or y >= self.numCol:
            return False
        return True

    # checks if a location is a peak or not
    def is_peak(self, location):
        return (self.get_better_neighbor(location) == location)

    # returns a matrix which is a sub_problem as you can see in divide and conquer algorithms
    def get_sub_problem(self, bounds):

        (sRow, sCol, nRow, nCol) = bounds
        new_bounds = (self.startRow + sRow, self.startCol + sCol, nRow, nCol)
        return peak(self.array, new_bounds)

    def get_subproblem_containing(self, boundList, location):

        (row, col) = location
        for (sRow, sCol, nRow, nCol) in boundList:
            if sRow <= row and row < sRow + nRow:
                if sCol <= col and col < sCol + nCol:
                    return self.get_sub_problem((sRow, sCol, nRow, nCol))

        # shouldn't reach here
        return self

    def get_location_in_self(self, problem, location):

        (row, col) = location
        newRow = row + problem.startRow - self.startRow
        newCol = col + problem.startCol - self.startCol
        return (newRow, newCol)


def get_dimensions(array):
    rows = len(array)
    cols = 0
    for row in array:
        if len(row) > cols:
            cols = len(row)
    return (rows, cols)


def create_problem(array):
    (rows, cols) = get_dimensions(array)
    return peak(array, (0, 0, rows, cols))
