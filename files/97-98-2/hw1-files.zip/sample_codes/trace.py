import peak


class TraceRecord(object):
    def __init__(self):
        self.sequence = []

    def get_maximum(self, arguments, maximum):
        self.sequence.append({
            "type": "findingMaximum",
            "coords": arguments
        })

        self.sequence.append({
            "type": "foundMaximum",
            "coord": maximum
        })

    def get_better_neighbor(self, neighbor, better):
        self.sequence.append({
            "type": "findingNeighbor",
            "coord": neighbor
        })

        if (neighbor != better):
            self.sequence.append({
                "type": "foundNeighbor",
                "coord": better
            })

    def set_problem_dimensions(self, subproblem):
        self.sequence.append({
            "type": "subproblem",
            "startRow": subproblem.startRow,
            "numRows": subproblem.numRow,
            "startCol": subproblem.startCol,
            "numCols": subproblem.numCol
        })

    def set_best_seen(self, bestSeen):
        self.sequence.append({
            "type": "bestSeen",
            "coord": bestSeen
        })

    def found_peak(self, peak):

        self.sequence.append({
            "type": "foundPeak",
            "coord": peak
        })
