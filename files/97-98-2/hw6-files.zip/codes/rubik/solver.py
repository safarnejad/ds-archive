import rubik

def shortest_path(start, end):
    """
    find the shortest path from start_position to
    end_position. Return a list of moves. 

    You can use the rubik.quarter_twists move set.
    Each move can be applied using rubik.perm_apply
    """
    raise NotImplementedError
