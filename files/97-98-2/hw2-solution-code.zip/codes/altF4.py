length = int(input())
    arr = list(map(int, input().split(" ")))
    for i in range(length):
        arr[i] += i
    arr.sort()
    answer = []
    creatable = True

    for i in range(length):
        answer.append(arr[i] - i)
        if i > 0 and answer[-1] < answer[-2]:
            creatable = False
    if creatable:
        print("Yes")
        answer_string = ""
        for i in range(length):
            answer_string += str(answer[i]) + " "
        print(answer_string[:-1])
    else:
        print("No")