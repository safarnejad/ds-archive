# import sys

def heapify(arr, n, i):
    largest = i  # Initialize largest as root
    l = 2 * i + 1  # left = 2*i + 1
    r = 2 * i + 2  # right = 2*i + 2

    # See if left child of root exists and is
    # greater than root
    if l < n and arr[i] < arr[l]:
        largest = l

        # See if right child of root exists and is
    # greater than root
    if r < n and arr[largest] < arr[r]:
        largest = r

        # Change root, if needed
    if largest != i:
        arr[i], arr[largest] = arr[largest], arr[i]  # swap

        # Heapify the root.
        heapify(arr, n, largest)

    # The main function to sort an array of given size


def heapSort(arr):
    n = len(arr)

    # Build a maxheap.
    for i in range(n, -1, -1):
        heapify(arr, n, i)

        # One by one extract elements
    for i in range(n - 1, 0, -1):
        arr[i], arr[0] = arr[0], arr[i]  # swap
        heapify(arr, i, 0)
    return arr
def root(i):
    if i%2==0:
        return i/2
    else:
        return (i-1)/2
def left(i):
    return 2*i
def right(i):
    return (2*i)+1
def inorderTraversal(list,i):
    res = []
    if i<len(list):
        res= res + inorderTraversal(list,left(i))
        res.append(list[i])
        res = res + inorderTraversal(list,right(i))
    return res
def minSwaps(arr):
    l = len(arr)

    aa=[]
    for i in range(l):
        aa.append([])
    for a, item in enumerate(arr):
        aa[a].append(item)
        aa[a].append(a)
    aa=heapSort(aa)

    vis = {k: False for k in range(l)}
    ans = 0
    for i in range(l):
        if vis[i] or aa[i][1] == i:
            continue
        cy_size = 0
        j = i
        while not vis[j]:
            vis[j] = True
            j = aa[j][1]
            cy_size += 1
        if cy_size > 0:
            ans += (cy_size - 1)
    return ans
n=int(input())
b = list(map(int, input().strip().split()))
lb=len(b)
a=[0]
for i in range(lb):
    a.append(b[i])
b=(inorderTraversal(a,1))
print((minSwaps(b)))