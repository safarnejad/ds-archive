class Node:
    def __init__(self, key):
        self.left = None
        self.right = None

        self.size = 1
        self.count = 1
        self.height = 1

        self.key = key

    # Subtree Informations
    def min_node_in_subtree(self):
        """
        returns the node with minimum key value in the subtree
        rooted by self
        """
        current_node = self
        while current_node.left:
            current_node = current_node.left
        return current_node

    # Node informations
    @staticmethod
    def size(node):
        return node.size if node else 0

    @staticmethod
    def height(node):
        return node.height if node else 0

    @staticmethod
    def balance(node):
        return Node.height(node.left) - Node.height(node.right) if node else 0

    # Node Operations
    @staticmethod
    def right_rotate(node):
        x = node.left
        y = x.right

        x.right = node
        node.left = y

        node.height = max(Node.height(node.left), Node.height(node.right)) + 1
        x.height = max(Node.height(x.left), Node.height(x.right)) + 1

        node.size = Node.size(node.left) + Node.size(node.right) + node.count
        x.size = Node.size(x.left) + Node.size(x.right) + x.count

        return x

    @staticmethod
    def left_rotate(node):
        x = node.right
        y = x.left

        x.left = node
        node.right = y
        node.height = max(Node.height(node.left), Node.height(node.right)) + 1
        x.height = max(Node.height(x.left), Node.height(x.right)) + 1

        node.size = Node.size(node.left) + Node.size(node.right) + node.count
        x.size = Node.size(x.left) + Node.size(x.right) + x.count

        return x


# Global Variables
counter = 0
MOD = 1000000007


# AVL TREE Implementation
# Based on Cpp implementation of AVL tree with duplicate keys
# source : https://www.geeksforgeeks.org/avl-with-duplicate-keys/
class AVLTree:
    # Variables
    root = None

    @staticmethod
    def _insert_node(root: Node, key: int):
        # if given root is None so we're creating a new root Node
        if not root:
            return Node(key)

        global counter
        # key is less than given root so it creates a displacement
        if key < root.key:
            # counting displacements
            counter += Node.size(root.right) % MOD + root.count % MOD
            root.left = AVLTree._insert_node(root.left, key)

        # key is greater than the given root so its ok
        else:
            if key > root.key:
                root.right = AVLTree._insert_node(root.right, key)

            # key is equal to the given root so we should save it as a count in the root
            else:
                root.count += 1
                root.size += 1
                counter += Node.size(root.right) % MOD
                return root

        # updating nodes
        root.height = max(Node.height(root.right), Node.height(root.left)) + 1
        root.size = root.count + Node.size(root.right) + Node.size(root.left)

        # insuring AVL property
        balance = Node.balance(root)

        if balance > 1 and key > root.left.key:
            root.left = Node.left_rotate(root.left)
            return Node.right_rotate(root)

        if balance > 1 and key < root.left.key:
            return Node.right_rotate(root)

        if balance < -1 and key < root.right.key:
            root.right = Node.right_rotate(root.right)
            return Node.left_rotate(root)

        if balance < -1 and key > root.right.key:
            return Node.left_rotate(root)

        return root

    @staticmethod
    def _delete_node(root: Node, key: int):
        # while deleting we should count all keys less than the key being deleted
        if not root:
            return root

        global counter

        if key < root.key:
            root.left = AVLTree._delete_node(root.left, key)

        else:
            if key > root.key:
                # counting root and its left children
                counter = (counter - Node.size(root.left) - root.count) % MOD
                root.right = AVLTree._delete_node(root.right, key)
            else:
                # key is equal to the key so all the left side of root should be counted
                counter -= Node.size(root.left) % MOD

                # if root has more than 1 instance of the given key
                if root.count > 1:
                    root.count -= 1
                    root.size -= 1
                    return root

                if not root.left or not root.right:
                    temp = root.left if root.left else root.right
                    if not temp:
                        temp = root
                        root = None
                        return None
                    else:
                        root = temp
                    del temp
                else:
                    temp = root.right.min_node_in_subtree()
                    root.key = temp.key
                    root.count = temp.count
                    temp.count = 1
                    root.right = AVLTree._delete_node(root.right, temp.key)

        if not root:
            return root

        root.height = 1 + max(Node.height(root.left), Node.height(root.right))
        root.size = Node.size(root.left) + Node.size(root.right) + root.count

        balance = Node.balance(root)

        if balance > 1 and Node.balance(root.left) >= 0:
            return Node.right_rotate(root)

        if balance > 1 and Node.balance(root.left) < 0:
            root.left = Node.left_rotate(root.left)
            return Node.right_rotate(root)

        if balance < -1 and Node.balance(root.right) <= 0:
            return Node.left_rotate(root)

        if balance < -1 and Node.balance(root.right) > 0:
            root.right = Node.right_rotate(root.right)
            return Node.left_rotate(root)

        return root

    def insert(self, key: int):
        self.root = AVLTree._insert_node(self.root, key)

    def delete(self, key: int):
        self.root = AVLTree._delete_node(self.root, key)


# Local Variables
root = None
answer = 0

# Getting input
n, k = list(map(int, input().split()))
input_list = list(map(int, input().split()))

# The idea is to create an AVL tree with K nodes
# while inserting a Node we count how many nodes were less
# than the new Node ( which is the number of displacements caused by that
# new number ) and while deleting a node from the AVL tree we count how many
# nodes in the tree were less than that node so that we know how many of the
# displacements in previous sequence were caused by the node being deleted
# so that we know the total displacement counts in the new sequence after inserting
# a new node !

# creating the initial AVL tree with
tree = AVLTree()
for i in range(k):
    tree.insert(input_list[i])

answer += counter

for i in range(n - k):
    tree.delete(input_list[i])
    tree.insert(input_list[i + k])
    answer += counter

print(answer % MOD)
