# Heap implementation gets from https://www.koderdojo.com/blog/binary-heap-and-heapq-in-python


MAX_INT = 2 ** 31 - 1


class Value:
    def __init__(self, value, key):
        self.value = value
        self.key = key
    
    def __cmp__(self, other):
        return self.value - other.value
    
    def __eq__(self, other):
        return self.value == other.value
    
    def __ne__(self, other):
        return self.value != other.value
    
    def __lt__(self, other):
        return self.value < other.value
    
    def __le__(self, other):
        return self.value <= other.value
    
    def __gt__(self, other):
        return self.value > other.value
    
    def __ge__(self, other):
        return self.value >= other.value


class Heap:
    def __init__(self):
        self.__heap = []
        self.__last_index = -1
    
    def push(self, value):
        self.__last_index += 1
        if self.__last_index < len(self.__heap):
            self.__heap[self.__last_index] = value
        else:
            self.__heap.append(value)
        self.__siftup(self.__last_index)
    
    def pop(self):
        if self.__last_index == -1:
            return None
    
        min_value = self.__heap[0]
        
        self.__heap[0] = self.__heap[self.__last_index]
        self.__last_index -= 1
        self.__siftdown(0)
        
            return min_value

def __siftup(self, index):
    while index > 0:
        parent_index, parent_value = self.__get_parent(index)
        
        if parent_value <= self.__heap[index]:
            break
            
            self.__heap[parent_index], self.__heap[index] = \
                self.__heap[index], self.__heap[parent_index]
            
            index = parent_index

def __siftdown(self, index):
    while True:
        index_value = self.__heap[index]
        
        left_child_index, left_child_value = self.__get_left_child(index, index_value)
            right_child_index, right_child_value = self.__get_right_child(index, index_value)
            
            if index_value <= left_child_value and index_value <= right_child_value:
                break
    
        if left_child_value < right_child_value:
            new_index = left_child_index
            else:
                new_index = right_child_index

        self.__heap[new_index], self.__heap[index] = \
            self.__heap[index], self.__heap[new_index]
            
            index = new_index
                
                def __get_parent(self, index):
if index == 0:
    return None, None
        
        parent_index = (index - 1) // 2
        
        return parent_index, self.__heap[parent_index]
    
    def __get_left_child(self, index, default_value):
        left_child_index = 2 * index + 1
        
        if left_child_index > self.__last_index:
            return None, default_value
        
        return left_child_index, self.__heap[left_child_index]

def __get_right_child(self, index, default_value):
    right_child_index = 2 * index + 2
        
        if right_child_index > self.__last_index:
            return None, default_value
    
    return right_child_index, self.__heap[right_child_index]

def __len__(self):
    return self.__last_index + 1


def get_inputs():
    k = int(input())
    n = int(input())
    list = [[_ for _ in range(k)] for _ in range(n)]
    for i in range(n):
        for j, value in enumerate(input().split()):
            list[i][j] = int(value)
    return list


def is_ended(indexes, k):
    for i in range(len(indexes)):
        if indexes[i] < k:
            return False
    return True


def create_ordered_list(inputes, indexes):
    answer = []
    minimum_list = Heap()
    for i in range(len(inputes)):
        minimum_list.push(Value(inputes[i][0], i))
    while not is_ended(indexes, len(inputes[0])):
        minimum = minimum_list.pop()
        index, minimum = minimum.key, minimum.value
        indexes[index] += 1
        if indexes[index] < len(inputes[1]):
            minimum_list.push(Value(inputes[index][indexes[index]], index))
        answer.append(minimum)
    return answer


def print_answer(list):
    for i in range(len(list)):
        print(list[i], end=' ')


def main():
    inputs = get_inputs()
    indexes = [0 for i in range(len(inputs))]
    print_answer(create_ordered_list(inputs, indexes))


if __name__ == '__main__':
    main()

