def binary_search(array: list, number: int, left: int, right: int):
    if left == right:
        if array[left] < number:
            return left + 1
        return left
    
    if left > right:
        return left
    
    mid = (left + right) // 2
    if array[mid] == number:
        return mid
    if array[mid] < number:
        return binary_search(array, number, mid + 1, right)
    return binary_search(array, number, left, mid - 1)


# initial values
input_count = 1000000
a_max = 100000

# initializing buckets
buckets = [[] for i in range(a_max)]

# getting input & sorting
for i in range(input_count):
    a, b = input().split()
    a, b = int(a), int(b)
    index = binary_search(
                          array=buckets[a],
                          number=b,
                          left=0,
                          right=len(buckets[a]) - 1
                          )
    buckets[a].insert(index, b)

for index, bucket in enumerate(buckets):
    for item in bucket:
        print(index, item)

